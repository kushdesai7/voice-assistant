
import speech_recognition as sr
from time import ctime
import webbrowser
import time
import playsound
import os
import random
import datetime
from gtts import gTTS
r = sr.Recognizer()

def record_audio(ask = False):
    with sr.Microphone() as source:
        audio = r.listen(source)
        if(ask):
            desai_speak(ask)
            print("LISTENING...")
            audio = r.listen(source)
            voice_data = " "
            try:
                voice_data = r.recognize_google(audio)
            except sr.UnknownValueError:
                desai_speak("sorry, i didnot get you")
            except sr.RequestError:
                desai_speak("sorry, i cant do that")
            return voice_data
def desai_speak(audio_string):
    tts = gTTS(text=audio_string,lang = 'en',slow= False)
    r = random.randint(1,1000000)
    audio_file = 'audio-' +str() +'.mp3'
    tts.save(audio_file)
    playsound.playsound(audio_file)
    print(audio_string)
    os.remove(audio_file)

def respond(voice_data):
    if 'who are you' or 'describe yourself'in voice_data:
        desai_speak("i am desai, i am kush's voice assistant")
    if 'what is your name' in voice_data:
        desai_speak("my name is desai")
    if 'what time is it' in voice_data:
        desai_speak(ctime())
    if 'search' in voice_data:
        search = record_audio('what do you want to search for')
        url = 'https://google.com/search?q='+ search
        webbrowser.get().open(url)
        desai_speak("here what i found for"+ search)
    if "find location" in voice_data:
        location=record_audio("what is the location")
        url='https://google.com/maps/place/'+ location
        webbrowser.get().open(url)
        desai_speak("here is the location"+location)
    if 'exit' in voice_data:
        desai_speak("thank you, have a nice day")
        exit()

def greetme():
    currentH = int(datetime.datetime.now().hour)
    if currentH >= 10 and currentH < 3:
        desai_speak("hi sir,good morning,how can i help you?")
    if currentH <= 15 and currentH != 19:
        desai_speak("hi sir,good evening,how can i help you?")
    if currentH >= 19 and currentH != 10:
        desai_speak("good night sir, its night but i always be there for you!")
time.sleep(1)
greetme()
while(1):
    voice_data = record_audio()
    respond(voice_data)




